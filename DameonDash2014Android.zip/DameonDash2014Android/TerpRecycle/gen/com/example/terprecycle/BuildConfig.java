/** Automatically generated file. DO NOT MODIFY */
package com.example.terprecycle;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}